man_joy_override
================

ROS node to allow manual override of commanded velocities with joystick for multiple connected machines
# Dependency
For zumy.launch
* odroid_machine: https://www.github.com/jlamyi/odroid_machine
* joy (ros package)
