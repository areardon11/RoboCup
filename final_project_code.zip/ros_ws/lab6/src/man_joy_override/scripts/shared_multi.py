
#Xbee settings
BS_COMPORT = '/dev/ttyUSB0'
BS_BAUDRATE = 57600     # Use this setting if your Xbee is set to baud rate of 57600
#BS_BAUDRATE = 111111    # Use this setting if your Xbee is set to baud rate of 115200

ROBOTS = []

#This message will be removed in the future. It is here to facilitate from the changeover
#to use of imageproc-settings in projects.
print "shared_multi.py from imageproc-settings"
