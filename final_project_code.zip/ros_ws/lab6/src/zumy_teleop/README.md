# zumy_teleop
A wrapper node of turtlebot_teleop for driving Zumy

## Dependency
turtlebot_teleop: http://wiki.ros.org/turtlebot_teleop

## Usage
roslaunch zumy_teleop zumy_teleop.launch mname:="your host name"
