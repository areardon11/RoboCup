^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package ar_track_alvar
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.5.1 (2015-04-14)
------------------
* Remove meta pkg; ar_track_alvar is 'unary stack' so no need for the meta pkg.
* Contributors: Scott Niekum, Isaac IY Saito

0.5.0 (2014-06-25)
------------------
* move README to root directory
* Merge remote-tracking branch 'origin/hydro-devel' into indigo-devel
* ar_track_alvar package uses ar_track_alvar_msgs
* restructuring packages. Separate out the message package.
* Contributors: Jihoon Lee

0.4.1 (2013-11-28)
------------------

0.3.3 (2013-02-22)
------------------

0.3.2 (2013-02-18)
------------------

0.3.1 (2013-02-14)
------------------

0.3.0 (2013-01-17)
------------------

0.2.0 (2012-08-08)
------------------
